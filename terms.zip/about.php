<?php
  // --- Page-Specific Variables ---
  // These variables are used by header.php to set the <title>, <meta> tags, and popup text.
  
  $pageTitle = "How to Use This Site | Hesten's Learning";
  $pageDescription = "A guide for students, teachers, and parents on how to get the most out of Hesten's Learning.";
  $pageKeywords = "how-to, guide, tutorial, students, teachers, parents, hesten's learning";
  $pageAuthor = "Hesten Allison"; // Based on footer
  
  // Welcome popup messages (from header.php)
  $welcomeMessage = "Welcome to the Guide!";
  $welcomeParagraph = "Find out how to get started as a student, parent, or teacher.";

  // --- Include Header ---
  // This file contains the <head>, <body> tag, accessibility panel, and navigation bar.
  include 'src/header.php';
?>

<!-- 
  START: Main Content
  This is the unique content for your "How-to-Use" page.
-->
<main class="container mx-auto p-4 md:p-8 min-h-screen">
  
  <!-- Page Header -->
  <header class="text-center mb-12">
    <h1 class="text-3xl md:text-5xl font-bold text-primary mb-4 transition-colors duration-300">
      How to Use This Site
    </h1>
    <p class="text-lg text-text-secondary max-w-3xl mx-auto transition-colors duration-300">
      Welcome! Whether you're a student ready to learn, a parent supporting your child, or a teacher managing a class, this guide will help you get started.
    </p>
  </header>

  <!-- 
    Tabbed Interface
    This provides a clean way for users to select their role.
  -->
  <div class="max-w-4xl mx-auto">
    
    <!-- Tab Buttons -->
    <div class="flex flex-col sm:flex-row justify-center border-b border-gray-300 dark:border-gray-700 mb-8" role="tablist" aria-label="User Guides">
      <!-- Student Tab -->
      <button id="tab-student" role="tab" aria-selected="true" aria-controls="panel-student"
        class="tab-button w-full sm:w-auto text-lg font-semibold py-4 px-6 -mb-px border-b-2 border-primary text-primary bg-transparent transition-all duration-300 ease-in-out flex items-center justify-center">
        <i class="fas fa-user-graduate mr-2" aria-hidden="true"></i>
        For Students
      </button>
      
      <!-- Teacher Tab -->
      <button id="tab-teacher" role="tab" aria-selected="false" aria-controls="panel-teacher"
        class="tab-button w-full sm:w-auto text-lg font-semibold py-4 px-6 text-text-secondary border-b-2 border-transparent hover:text-primary transition-all duration-300 ease-in-out flex items-center justify-center">
        <i class="fas fa-chalkboard-user mr-2" aria-hidden="true"></i>
        For Teachers
      </button>
      
      <!-- Parent Tab -->
      <button id="tab-parent" role="tab" aria-selected="false" aria-controls="panel-parent"
        class="tab-button w-full sm:w-auto text-lg font-semibold py-4 px-6 text-text-secondary border-b-2 border-transparent hover:text-primary transition-all duration-300 ease-in-out flex items-center justify-center">
        <i class="fas fa-user-shield mr-2" aria-hidden="true"></i>
        For Parents
      </button>
    </div>

    <!-- Tab Panels (Content) -->
    <div class="tab-panels">
      
      <!-- Student Panel -->
      <div id="panel-student" role="tabpanel" aria-labelledby="tab-student"
        class="tab-panel bg-content-bg text-text-default rounded-xl shadow-lg p-6 md:p-8 transition-all duration-300">
        
        <h2 class="text-2xl font-bold text-primary mb-6 flex items-center">
          <i class="fas fa-user-graduate mr-3" aria-hidden="true"></i>
          Student's Guide
        </h2>
        
        <div class="space-y-4 prose max-w-none text-text-default prose-headings:text-primary prose-a:text-link">
          <p>Welcome, students! This platform is built to help you learn at your own pace. Here's how to get started:</p>
          
          <h3 class="text-xl font-semibold">1. Your Dashboard</h3>
          <p>After you log in, you'll land on your dashboard. This is your home base! From here, you can see your assigned courses, track your progress, and see any new announcements from your teacher.</p>
          
          <h3 class="text-xl font-semibold">2. Finding & Starting Lessons</h3>
          <p>Use the "Learning" or "Curriculum" links in the navigation bar to browse available subjects. You can also use the search bar at the top of the page to find specific topics. Click on a lesson to start!</p>
          
          <h3 class="text-xl font-semibold">3. Taking Assessments</h3>
          <p>Your teacher may assign assessments to check your understanding. You can find these in your dashboard or in the "Assessment" section. Don't worry, these are just to help you and your teacher know what to focus on.</p>
          
          <h3 class="text-xl font-semibold">4. Using the Accessibility Tools</h3>
          <p>We want to make learning comfortable for you. Click the <i class="fas fa-universal-access" aria-hidden="true"></i> icon in the bottom-right corner to open the accessibility panel. You can:</p>
          <ul>
            <li>Change the theme (Light, Dark, High-Contrast).</li>
            <li>Change the font to one that's easier for you to read (like Open Dyslexic).</li>
            <li>Increase the text size and line spacing.</li>
            <li>Turn on the "Reading Guide" to help you focus on one line at a time.</li>
          </ul>
        </div>

      </div>

      <!-- Teacher Panel -->
      <div id="panel-teacher" role="tabpanel" aria-labelledby="tab-teacher"
        class="tab-panel hidden bg-content-bg text-text-default rounded-xl shadow-lg p-6 md:p-8 transition-all duration-300">
        
        <h2 class="text-2xl font-bold text-primary mb-6 flex items-center">
          <i class="fas fa-chalkboard-user mr-3" aria-hidden="true"></i>
          Teacher's Guide
        </h2>
        
        <div class="space-y-4 prose max-w-none text-text-default prose-headings:text-primary prose-a:text-link">
          <p>Welcome, teachers! We're excited to help you create a personalized learning environment for your students. Here’s a quick overview:</p>
          
          <h3 class="text-xl font-semibold">1. Setting Up Your Class</h3>
          <p>Once your account is created, your first step is to create a class. You'll get a unique class code that your students can use to join.</p>
          
          <h3 class="text-xl font-semibold">2. Managing Students</h3>
          <p>From your teacher dashboard, you can view all the students in your class, reset their passwords, and monitor their activity.</p>
          
          <h3 class="text-xl font-semibold">3. Assigning Content</h3>
          <p>Browse the full curriculum and assign specific lessons, modules, or assessments to your entire class or to individual students. This is perfect for differentiated instruction.</p>
          
          <h3 class="text-xl font-semibold">4. Monitoring Progress</h3>
          <p>The "Progress" or "Reports" section is your command center. You can see at-a-glance which students are excelling and which might need extra support. You can also view detailed results from assessments.</p>
        </div>

      </div>

      <!-- Parent Panel -->
      <div id="panel-parent" role="tabpanel" aria-labelledby="tab-parent"
        class="tab-panel hidden bg-content-bg text-text-default rounded-xl shadow-lg p-6 md:p-8 transition-all duration-300">
        
        <h2 class="text-2xl font-bold text-primary mb-6 flex items-center">
          <i class="fas fa-user-shield mr-3" aria-hidden="true"></i>
          Parent's Guide
        </h2>
        
        <div class="space-y-4 prose max-w-none text-text-default prose-headings:text-primary prose-a:text-link">
          <p>Welcome, parents! We believe that your support is crucial to your child's success. Here’s how you can stay involved:</p>
          
          <h3 class="text-xl font-semibold">1. Creating Your Account</h3>
          <p>First, create your own parent account. After you're set up, you can link to your child's account using a unique code provided by their teacher or found in their account settings.</p>
          
          <h3 class="text-xl font-semibold">2. Viewing Your Child's Progress</h3>
          <p>Your parent dashboard gives you a "read-only" view of your child's learning. You can see:
            <ul>
              <li>Which lessons they have completed.</li>
              <li>Their scores on recent assessments.</li>
              <li>Any upcoming assignments or due dates.</li>
            </ul>
          </p>
          
          <h3 class="text-xl font-semibold">3. Understanding the Curriculum</h3>
          <p>Feel free to browse the curriculum sections to see what your child is learning. This can help you have supportive conversations about their schoolwork at home.</p>
          
          <h3 class="text-xl font-semibold">4. Exploring Accessibility Features</h3>
          <p>We encourage you to explore the accessibility panel (the <i class="fas fa-universal-access" aria-hidden="true"></i> icon) *with* your child. You can help them find the font size, theme, and reading tools that make them feel most comfortable and confident.</p>
        </div>

      </div>

    </div>
  </div>

</main>
<!-- 
  END: Main Content
-->

<!-- 
  JavaScript for Tab Functionality
  This script must come *before* the footer include, which closes the <body>.
-->
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.tab-button');
    const panels = document.querySelectorAll('.tab-panel');

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        // Get the target panel ID from the 'aria-controls' attribute
        const targetPanelId = tab.getAttribute('aria-controls');

        // Deactivate all tabs
        tabs.forEach(t => {
          t.setAttribute('aria-selected', 'false');
          t.classList.remove('border-primary', 'text-primary');
          t.classList.add('text-text-secondary', 'border-transparent');
        });

        // Hide all panels
        panels.forEach(panel => {
          panel.classList.add('hidden');
        });

        // Activate the clicked tab
        tab.setAttribute('aria-selected', 'true');
        tab.classList.add('border-primary', 'text-primary');
        tab.classList.remove('text-text-secondary', 'border-transparent');

        // Show the target panel
        const targetPanel = document.getElementById(targetPanelId);
        if (targetPanel) {
          targetPanel.classList.remove('hidden');
        }
      });
    });
  });
</script>

<?php
  // --- Include Footer ---
  // This file contains the <footer>, modals, global scripts, 
  // and closing </body> and </html> tags.
  include 'src/footer.php';
?>