<?php
// --- Page-Specific Variables ---
// These variables will be used by header.php
$pageTitle = 'Hesten\'s Learning Library';
$pageDescription = 'Browse your personal collection of digital books in a Netflix-style interface.';
$pageKeywords = 'library, books, epub, pdf, digital library, collection';
$pageAuthor = 'Hesten\'s Learning'; // Or your site name
$welcomeMessage = "Welcome to Hesten\ 's Learning Library";

// --- TYPO FIX ---
// Changed "leashure" to "leisure"
$welcomeParagraph = "Please take a look around and read at your leisure.";

// --- Book Data Array ---
// In a real application, you would fetch this data from your database.
$categories = [
    "Recently Added" => [
        [
            "id" => "midnight-library", // <-- FUTURE IMPROVEMENT: Add a unique ID
            "title" => "The Midnight Library",
            "author" => "Matt Haig",
            "isbn" => "978-0735211292",
            "date" => "2020-09-29",
            "img" => "https://placehold.co/300x450/7c3aed/white?text=The+Midnight\nLibrary",
            "description" => "Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived. To see how things would be if you had made other choices... Would you have done anything different, if you had the chance to undo your regrets?",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "850L" // Example Lexile
        ],
        [
            "id" => "dune",
            "title" => "Dune",
            "author" => "Frank Herbert",
            "isbn" => "978-0441172719",
            "date" => "1965-08-01",
            "img" => "https://placehold.co/300x450/e89f33/black?text=Dune",
            "description" => "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the 'spice' melange, a drug capable of extending life and enhancing consciousness. A stunning blend of adventure and mysticism, environmentalism, and politics.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1080L" // Example Lexile
        ],
        [
            "id" => "atomic-habits",
            "title" => "Atomic Habits",
            "author" => "James Clear",
            "isbn" => "978-0735211292",
            "date" => "2018-10-16",
            "img" => "https://placehold.co/300x450/3498db/white?text=Atomic\nHabits",
            "description" => "An easy and proven way to build good habits and break bad ones. James Clear, an expert on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1100L" // Example Lexile
        ],
        [
            "id" => "project-hail-mary",
            "title" => "Project Hail Mary",
            "author" => "Andy Weir",
            "isbn" => "978-0593135204",
            "date" => "2021-05-04",
            "img" => "https://placehold.co/300x450/f39c12/black?text=Project+Hail+Mary",
            "description" => "A lone astronaut. An impossible mission. An ally he never expected. Ryland Grace is the sole survivor on a desperate, last-chance mission—and if he fails, humanity and the earth itself will perish.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "990L" // Example Lexile
        ],
        [
            "id" => "placeholder-1",
            "title" => "Placeholder Book 1",
            "author" => "Author 1",
            "isbn" => "123-456",
            "date" => "2023-01-01",
            "img" => "https://placehold.co/300x450/2ecc71/black?text=Book+One",
            "description" => "Description for placeholder book 1.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "" // Example empty
        ],
        [
            "id" => "placeholder-2",
            "title" => "Placeholder Book 2",
            "author" => "Author 2",
            "isbn" => "123-457",
            "date" => "2023-02-01",
            "img" => "https://placehold.co/300x450/e74c3c/white?text=Book+Two",
            "description" => "Description for placeholder book 2.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "Grades 4-6" // Example grade level
        ],
        [
            "id" => "placeholder-3",
            "title" => "Placeholder Book 3",
            "author" => "Author 3",
            "isbn" => "123-458",
            "date" => "2023-03-01",
            "img" => "https://placehold.co/300x450/9b59b6/white?text=Book+Three",
            "description" => "Description for placeholder book 3.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => ""
        ],
        [
            "id" => "placeholder-4",
            "title" => "Placeholder Book 4",
            "author" => "Author 4",
            "isbn" => "123-459",
            "date" => "2023-04-01",
            "img" => "https://placehold.co/300x450/1abc9c/black?text=Book+Four",
            "description" => "Description for placeholder book 4.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "800L"
        ],
    ],
    "Classic Fiction" => [
        [
            "id" => "1984",
            "title" => "1984",
            "author" => "George Orwell",
            "isbn" => "978-0451524935",
            "date" => "1949-06-08",
            "img" => "https://m.media-amazon.com/images/I/71wANojhEKL._AC_UF1000,1000_QL80_.jpg",
            "fallback-img" => "https://placehold.co/300x450/c0392b/white?text=1984",
            "description" => "A dystopian social science fiction novel and cautionary tale. The story follows the life of Winston Smith, a low-ranking member of 'the Party,' who is frustrated by the omnipresent eyes of the party, and its ominous ruler Big Brother.",
            "pdf-link" => "https://cdn.hestena62.com/library/Nineteen%20eighty-four%20-%20Goerge%20Orwell.pdf",
            "epub-link" => "https://cdn.hestena62.com/library/Nineteen%20eighty-four%20-%20George%20Orwell.epub",
            "read-online-link" => "/library/read/1984.php",
            // --- NEW FIELDS (Updated from description) ---
            "txt-link" => "https://cdn.hestena62.com/library/Nineteen%20eighty-four%20-%20George%20Orwell.txt", // Add your link here
            "mobi-link" => "https://cdn.hestena62.com/library/Nineteen%20eighty-four%20-%20George%20Orwell.mobi", // Add your link here
            "word-link" => "https://cdn.hestena62.com/library/Nineteen%20eighty-four%20-%20George%20Orwell.docx", // Add your link here
            "lexile" => "1090L"
        ],
        [
            "id" => "mockingbird",
            "title" => "To Kill a Mockingbird",
            "author" => "Harper Lee",
            "isbn" => "978-0061120084",
            "date" => "1960-07-11",
            "img" => "https://placehold.co/300x450/ecf0f1/black?text=To+Kill+a\nMockingbird",
            "description" => "The unforgettable novel of a childhood in a sleepy Southern town and the crisis of conscience that rocked it. To Kill A Mockingbird became both an instant bestseller and a critical success when it was first published in 1960. It went on to win the Pulitzer Prize in 1961.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            // --- NEW FIELDS ---
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "870L" // Example Lexile
        ],
        // ... other books with unique IDs ...
    ],
    "Science Fiction" => [
        [
            "id" => "ender-s-game",
            "title" => "Ender's Game",
            "author" => "Orson Scott Card",
            "isbn" => "978-0812550702",
            "date" => "1985-01-15",
            "img" => "https://placehold.co/300x450/2980b9/white?text=Ender's+Game",
            "description" => "In order to develop a secure defense against a hostile alien race's next attack, government agencies breed child geniuses and train them as soldiers. A brilliant young boy, Andrew 'Ender' Wiggin lives with his kind but distant parents, his sadistic brother Peter, and the person he loves more than anyone else, his sister Valentine. Peter and Valentine were candidates for the soldier-training program but didn't make the cut—young Ender is the Wiggin drafted to the orbiting Battle School for rigorous military training.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "780L"
        ],
        [
            "id" => "neuromancer",
            "title" => "Neuromancer",
            "author" => "William Gibson",
            "isbn" => "978-0441569595",
            "date" => "1984-07-01",
            "img" => "https://placehold.co/300x450/95a5a6/white?text=Neuromancer",
            "description" => "The sky above the port was the color of television, tuned to a dead channel. Case was the sharpest data-thief in the matrix, until he crossed the wrong people and they crippled his nervous system, locking him out of cyberspace. Now a new employer has recruited him for a last-chance run against an unthinkably powerful artificial intelligence. With a mirror-eyed street samurai and a dead man's personality construct, he's up against a surreal world of corporate espionage and high-tech lowlifes.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "910L"
        ],
        [
            "id" => "snow-crash",
            "title" => "Snow Crash",
            "author" => "Neal Stephenson",
            "isbn" => "978-0553380958",
            "date" => "1992-06-01",
            "img" => "https://placehold.co/300x450/bdc3c7/black?text=Snow+Crash",
            "description" => "In reality, Hiro Protagonist delivers pizza for Uncle Enzo’s CosoNostra Pizza Inc., but in the Metaverse he’s a warrior prince. Plunging headlong into the enigma of a new computer virus that’s striking down hackers everywhere, he races along the neon-lit streets on a search-and-destroy mission for the shadowy virtual villain threatening to bring about infocalypse.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1030L"
        ],
    ],
    "Fantasy" => [
        [
            "id" => "the-hobbit",
            "title" => "The Hobbit",
            "author" => "J.R.R. Tolkien",
            "isbn" => "978-0345339683",
            "date" => "1937-09-21",
            "img" => "https://placehold.co/300x450/27ae60/white?text=The+Hobbit",
            "description" => "A great modern classic and the prelude to The Lord of the Rings. Bilbo Baggins is a hobbit who enjoys a comfortable, unambitious life, rarely traveling any farther than his pantry or cellar. But his contentment is disturbed when the wizard Gandalf and a company of dwarves arrive on his doorstep one day to whisk him away on an adventure. They have launched a plot to raid the treasure hoard guarded by Smaug the Magnificent, a large and very dangerous dragon.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1000L"
        ],
        [
            "id" => "the-name-of-the-wind",
            "title" => "The Name of the Wind",
            "author" => "Patrick Rothfuss",
            "isbn" => "978-0756404741",
            "date" => "2007-03-27",
            "img" => "https://placehold.co/300x450/e67e22/white?text=The+Name+of+the+Wind",
            "description" => "Told in Kvothe's own voice, this is the tale of the magically gifted young man who grows to be the most notorious wizard his world has ever seen. The intimate narrative of his childhood in a troupe of traveling players, his years spent as a near-feral orphan in a crime-ridden city, his daringly brazen yet successful bid to enter a legendary school of magic, and his life as a fugitive after the murder of a noble are illuminated in this unforgettable story that takes readers deep into the mind of a living legend.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1090L"
        ],
        [
            "id" => "the-colour-of-magic",
            "title" => "The Colour of Magic",
            "author" => "Terry Pratchett",
            "isbn" => "978-0062225672",
            "date" => "1983-11-24",
            "img" => "https://placehold.co/300x450/f1c40f/black?text=The+Colour+of+Magic",
            "description" => "On a world supported on the back of a giant turtle (sex unknown), a gleeful, explosive, wickedly eccentric expedition sets out. There's an avaricious but inept wizard, a naive tourist whose luggage moves on hundreds of dear little legs, dragons who only exist if you believe in them, and of course THE EDGE of the planet.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "960L"
        ],
    ],
    "Non-Fiction" => [
        [
            "id" => "sapiens",
            "title" => "Sapiens: A Brief History of Humankind",
            "author" => "Yuval Noah Harari",
            "isbn" => "978-0062316097",
            "date" => "2015-02-10",
            "img" => "https://placehold.co/300x450/8e44ad/white?text=Sapiens",
            "description" => "One hundred thousand years ago, at least six different species of humans inhabited Earth. Yet today there is only one—homo sapiens. What happened to the others? And what may happen to us? Most books about the history of humanity pursue either a historical or a biological approach, but Dr. Yuval Noah Harari breaks the mold with this highly original book that begins about 70,000 years ago with the appearance of modern cognition.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1070L"
        ],
        [
            "id" => "a-brief-history-of-time",
            "title" => "A Brief History of Time",
            "author" => "Stephen Hawking",
            "isbn" => "978-0553380163",
            "date" => "1988-04-01",
            "img" => "https://placehold.co/300x450/34495e/white?text=A+Brief+History+of+Time",
            "description" => "A landmark volume in science writing by one of the great minds of our time, Stephen Hawking’s book explores such profound questions as: How did the universe begin—and what made its start possible? Does time always flow forward? Is the universe unending—or are there boundaries? Are there other dimensions in space? What will happen when it all ends? Told in language we all can understand, A Brief History of Time plunges into the exotic realms of black holes and quarks, of antimatter and \"arrows of time,\" of the big bang and a bigger God—where the possibilities are wondrous and unexpected.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1290L"
        ],
        [
            "id" => "cosmos",
            "title" => "Cosmos",
            "author" => "Carl Sagan",
            "isbn" => "978-0345539434",
            "date" => "1980-10-12",
            "img" => "https://placehold.co/300x450/16a085/white?text=Cosmos",
            "description" => "Cosmos is one of the bestselling science books of all time. In clear-eyed prose, Sagan reveals a jewel-like blue world inhabited by a life form that is just beginning to discover its own identity and to venture into the vast ocean of space. Featuring a new Introduction by Ann Druyan, full color illustrations, and a new Foreword by Neil deGrasse Tyson, Cosmos retraces the fourteen billion years of cosmic evolution that have transformed matter into consciousness, exploring such topics as the origin of life, the human brain, Egyptian hieroglyphics, spacecraft missions, the death of the Sun, the evolution of galaxies, and the forces and individuals who helped to shape modern science.",
            "pdf-link" => "#",
            "epub-link" => "#",
            "read-online-link" => "#",
            "txt-link" => "#",
            "mobi-link" => "#",
            "word-link" => "#",
            "lexile" => "1280L"
        ],
    ],
    
    // ... other categories ...
];

// --- Include Header ---
// This file contains the <head>, <body> tag, and navigation
require_once 'src/header.php';
?>

<!-- 
    --- Page-Specific Styles ---
    IMPROVEMENT: Consider moving this to an external CSS file (e.g., /css/library.css)
    and including it in header.php for better organization.
-->
<style>
    /* Customize scrollbars for a cleaner look */
    .book-row::-webkit-scrollbar {
        height: 8px;
    }
    .book-row::-webkit-scrollbar-track {
        /* Use theme-aware colors */
        background: var(--color-content-bg, #2d3748); 
        border-radius: 10px;
    }
    .book-row::-webkit-scrollbar-thumb {
        background: var(--color-secondary, #4a5568);
        border-radius: 10px;
    }
    .book-row::-webkit-scrollbar-thumb:hover {
        background: var(--color-primary, #718096);
    }

    /* Book cover styles */
    .book-cover {
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    }
    .book-cover:hover {
        transform: scale(1.05);
        box-shadow: 0 10px 20px rgba(0,0,0,0.5);
    }
    
    /* Modal fade-in */
    .modal-fade {
        transition: opacity 0.3s ease;
    }

    /* --- IMPROVEMENT: Hide download buttons if they are disabled --- */
    .download-link[href="#"],
    .download-link[href=""] {
        display: none;
    }

    /* --- NEW: Hide Lexile info if it's empty --- */
    #modal-lexile-container:empty {
        display: none;
    }
</style>

<!-- 
    --- Work in Progress Popup ---
    This is a one-time popup for the library page.
-->
<div id="work-in-progress-popup" class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 hidden" role="dialog"
    aria-modal="true" aria-labelledby="wip-popup-title">
    <!-- content-bg makes this modal theme-aware -->
    <div class="bg-content-bg rounded-xl shadow-2xl p-8 max-w-lg w-full text-center relative mx-4">
      <h2 id="wip-popup-title" class="text-2xl font-bold mb-4 text-primary">A Note from Hesten</h2>
      <!-- text-text-default makes this modal theme-aware -->
      <p class="mb-6 text-text-default text-lg">
        Please enjoy the books with images, as I am adding books one at a time.
      </p>
      <button id="close-wip-popup"
        class="bg-primary text-white px-6 py-2 rounded-full font-semibold hover:bg-secondary transition focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
        aria-label="Close this note">
        Got it!
      </button>
    </div>
</div>

<!-- 
    --- Main Page Content ---
    This is the unique content for the library page.
-->
<div class="container mx-auto px-4 py-8">

    <?php
    // --- Dynamic Category & Book Rendering ---
    // Loop through each Category
    foreach ($categories as $categoryName => $books) :
    ?>
        
        <!-- Category Section -->
        <section class="mb-12">
            <!-- Category Title, using theme-aware text color -->
            <h2 class="text-2xl font-semibold mb-4 text-text-secondary"><?php echo htmlspecialchars($categoryName); ?></h2>
            
            <!-- Book Row -->
            <div class="book-row flex space-x-4 overflow-x-auto pb-4">
                
                <?php
                // Loop through each Book in the Category
                foreach ($books as $book) :
                ?>

                    <!-- 
                        Book Item
                        ---
                        Pass all book data as data- attributes
                    -->
                    <div class="flex-shrink-0 cursor-pointer group" 
                         onclick="openModal(this)"
                         data-title="<?php echo htmlspecialchars($book['title']); ?>"
                         data-author="<?php echo htmlspecialchars($book['author']); ?>"
                         data-isbn="<?php echo htmlspecialchars($book['isbn']); ?>"
                         data-date="<?php echo htmlspecialchars($book['date']); ?>"
                         data-img="<?php echo htmlspecialchars($book['img']); ?>"
                         data-description="<?php echo htmlspecialchars($book['description']); ?>"
                         data-pdf-link="<?php echo htmlspecialchars($book['pdf-link']); ?>"
                         data-epub-link="<?php echo htmlspecialchars($book['epub-link']); ?>"
                         data-read-online-link="<?php echo htmlspecialchars($book['read-online-link'] ?? '#'); ?>"
                         
                         <?php // --- NEW DATA ATTRIBUTES --- ?>
                         data-txt-link="<?php echo htmlspecialchars($book['txt-link'] ?? '#'); ?>"
                         data-mobi-link="<?php echo htmlspecialchars($book['mobi-link'] ?? '#'); ?>"
                         data-word-link="<?php echo htmlspecialchars($book['word-link'] ?? '#'); ?>"
                         data-lexile="<?php echo htmlspecialchars($book['lexile'] ?? ''); ?>"
                         >
                        
                        <img src="<?php echo htmlspecialchars($book['img']); ?>" 
                             alt="<?php echo htmlspecialchars($book['title']); ?>"
                             class="book-cover w-40 h-60 md:w-48 md:h-72 object-cover rounded-lg"
                             onerror="this.onerror=null; this.src='<?php echo isset($book['fallback-img']) ? htmlspecialchars($book['fallback-img']) : 'https://placehold.co/300x450/6b7280/white?text=Image+Not+Found'; ?>';">
                    </div>

                <?php endforeach; // End book loop ?>

            </div> <!-- End book-row -->
        </section> <!-- End Category Section -->

    <?php endforeach; // End category loop ?>

</div>



<div id="bookModal" class="modal-fade hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4 opacity-0" onclick="closeModal()">
    
    <!-- Use bg-content-bg for theme-aware background -->
    <div class="bg-content-bg rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
        <!-- Modal Content -->
        <div class="flex flex-col md:flex-row">
            <!-- Book Cover -->
            <img id="modal-img" src="https://placehold.co/300x450" alt="Book Cover" class="w-full md:w-1/3 h-auto object-cover rounded-l-lg">
            
            <!-- Book Details -->
            <div class="p-6 md:p-8 flex-1">
                <div class="flex justify-between items-start mb-2">
                    <!-- Use text-text-default for theme-aware text -->
                    <h2 id="modal-title" class="text-3xl font-bold text-text-default">Book Title</h2>
                    <button onclick="closeModal()" class="text-text-secondary hover:text-text-default text-3xl font-bold">&times;</button>
                </div>
                
                <!-- Use text-primary for theme-aware accent color -->
                <p id="modal-author" class="text-lg text-primary mb-4">by Author Name</p>
                
                <!-- Use text-text-secondary for theme-aware body text -->
                <p id="modal-description" class="text-text-secondary mb-6 leading-relaxed">Book description goes here.</p>

                <h3 class="text-xl font-semibold mb-3 text-text-default">Book Info</h3>
                <div class="grid grid-cols-2 gap-x-4 gap-y-2 text-text-secondary mb-6">
                    <div>
                        <strong class="text-text-default">ISBN:</strong>
                        <span id="modal-isbn">000-0000000000</span>
                    </div>
                    <div>
                        <strong class="text-text-default">Published:</strong>
                        <span id="modal-date">YYYY-MM-DD</span>
                    </div>
                    
                    <!-- --- NEW LEXILE/GRADE LEVEL SECTION --- -->
                    <!-- This div will be hidden by CSS if it's empty -->
                    <div class="col-span-2" id="modal-lexile-container">
                        <strong class="text-text-default">Reading Level:</strong>
                        <span id="modal-lexile"></span>
                    </div>
                </div>

                <h3 class="text-xl font-semibold mb-3 text-text-default">Downloads</h3>
                <div class="flex flex-wrap gap-4">
                    
                    <a id="modal-read-online-link" href="#" class="download-link inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition duration-200 shadow-md">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                        Read Online
                    </a>
                    
                    <!-- PDF Button (Styled with red) -->
                    <a id="modal-pdf-link" href="#" class="download-link inline-flex items-center px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition duration-200 shadow-md">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        PDF
                    </a>
                    <!-- ePub Button (Styled with blue) -->
                    <a id="modal-epub-link" href="#" class="download-link inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition duration-200 shadow-md">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.747 0-3.332.477-4.5 1.253"></path></svg>
                        Epub
                    </a>

                    <!-- --- NEW DOWNLOAD BUTTONS --- -->
                    
                    <!-- TXT Button (Styled with gray) -->
                    <a id="modal-txt-link" href="#" class="download-link inline-flex items-center px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white font-semibold rounded-lg transition duration-200 shadow-md">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        TXT
                    </a>
                    
                    <!-- MOBI Button (Styled with orange) -->
                    <a id="modal-mobi-link" href="#" class="download-link inline-flex items-center px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-lg transition duration-200 shadow-md">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.747 0-3.332.477-4.5 1.253"></path></svg>
                        MOBI
                    </a>

                    <!-- Word Button (Styled with dark blue) -->
                    <a id="modal-word-link" href="#" class="download-link inline-flex items-center px-6 py-3 bg-blue-800 hover:bg-blue-900 text-white font-semibold rounded-lg transition duration-200 shadow-md">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h7"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 4v16m4-16v16"></path></svg>
                        Word
                    </a>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- 
    --- Page-Specific JavaScript ---
    IMPROVEMENT: Consider moving these scripts to an external JS file (e.g., /js/library.js)
    and including it in footer.php for better organization.
-->
<script>
// --- WIP Popup Script ---
document.addEventListener("DOMContentLoaded", function () {
    const popup = document.getElementById("work-in-progress-popup");
    const closeBtn = document.getElementById("close-wip-popup");
    const POPUP_STORAGE_KEY = 'hl_library_wip_dismissed';

    if (popup && closeBtn) {
        // Check if popup was already dismissed
        try {
            if (localStorage.getItem(POPUP_STORAGE_KEY) === 'true') {
                popup.classList.add("hidden");
                return; // Don't show it
            }
        } catch (e) {
            console.warn("Could not read from localStorage", e);
        }

        // If not dismissed, show it
        popup.classList.remove("hidden");

        // Attach listener to close button
        closeBtn.addEventListener("click", function () {
            popup.classList.add("hidden");
            // Save dismissed state
            try {
                localStorage.setItem(POPUP_STORAGE_KEY, 'true');
            } catch (e) {
                console.warn("Could not write to localStorage", e);
            }
        });
        
        // Auto-focus the close button for accessibility
        closeBtn.focus();
    }
});

// --- Book Modal Script ---
(function() {
    const modal = document.getElementById('bookModal');
    if (!modal) return; // Guard clause if modal isn't on the page

    // Get modal elements once
    const modalTitle = document.getElementById('modal-title');
    const modalAuthor = document.getElementById('modal-author');
    const modalDescription = document.getElementById('modal-description');
    const modalIsbn = document.getElementById('modal-isbn');
    const modalDate = document.getElementById('modal-date');
    const modalImg = document.getElementById('modal-img');
    const modalPdfLink = document.getElementById('modal-pdf-link');
    const modalEpubLink = document.getElementById('modal-epub-link');
    const modalReadOnlineLink = document.getElementById('modal-read-online-link');
    
    // --- NEW MODAL ELEMENTS ---
    const modalLexileContainer = document.getElementById('modal-lexile-container');
    const modalLexile = document.getElementById('modal-lexile');
    const modalTxtLink = document.getElementById('modal-txt-link');
    const modalMobiLink = document.getElementById('modal-mobi-link');
    const modalWordLink = document.getElementById('modal-word-link');


    // Make functions available globally
    window.openModal = function(element) {
        // Get all data from the clicked element
        const data = element.dataset;

        // Populate the modal fields
        modalTitle.textContent = data.title;
        modalAuthor.textContent = 'by '.concat(data.author);
        modalDescription.textContent = data.description;
        modalIsbn.textContent = data.isbn;
        modalDate.textContent = data.date;
        modalImg.src = data.img;
        
        // Set href for links
        modalPdfLink.href = data.pdfLink;
        modalEpubLink.href = data.epubLink;
        modalReadOnlineLink.href = data.readOnlineLink;

        // --- POPULATE NEW FIELDS ---
        modalTxtLink.href = data.txtLink;
        modalMobiLink.href = data.mobiLink;
        modalWordLink.href = data.wordLink;

        // Populate Lexile/Grade level
        if (data.lexile) {
            modalLexile.textContent = data.lexile;
            // Ensure container is visible (it's hidden by CSS if empty)
            modalLexileContainer.style.display = 'block'; 
        } else {
            modalLexile.textContent = '';
            // Hide container
            modalLexileContainer.style.display = 'none';
        }

        // Show the modal with a fade-in effect
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.remove('opacity-0');
        }, 10); // Short delay to allow CSS transition to apply
    }

    window.closeModal = function() {
        // Fade-out effect
        modal.classList.add('opacity-0');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300); // Must match the transition duration
    }

    // Close modal if escape key is pressed
    window.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !modal.classList.contains('hidden')) {
            closeModal();
        }
    });
})();
</script>

<?php
// --- Include Footer ---
// This file contains the footer, global modals, and closing </body>/</html> tags
require_once 'src/footer.php';
?>